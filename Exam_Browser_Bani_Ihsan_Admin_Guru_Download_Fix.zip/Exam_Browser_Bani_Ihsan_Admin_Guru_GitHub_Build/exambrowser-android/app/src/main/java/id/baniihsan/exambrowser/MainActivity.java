package id.baniihsan.exambrowser;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.app.AlertDialog;
import android.content.Intent;
import android.util.Base64;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private FrameLayout root;
    private View home;
    private boolean inWeb = false;
    private static final String ADMIN_URL = "https://admin-ujian-bani-ihsan.pages.dev/";
    private static final String GURU_URL = "https://guru-ujian-bani-ihsan.pages.dev/";
    private static final int CREATE_FILE_REQUEST = 4107;

    private byte[] pendingBytes;
    private String pendingMime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    private String pendingName = "Nilai_Ujian_Bani_Ihsan.xlsx";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8, 53, 132));
        getWindow().setNavigationBarColor(Color.rgb(5, 30, 76));
        buildHome();
    }

    private void buildHome() {
        root = new FrameLayout(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(dp(22), dp(24), dp(22), dp(24));
        page.setBackgroundColor(Color.rgb(5, 67, 157));

        ImageView logo = new ImageView(this);
        int imageId = getResources().getIdentifier("exam_logo", "drawable", getPackageName());
        if (imageId != 0) logo.setImageResource(imageId);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        page.addView(logo, new LinearLayout.LayoutParams(-1, 0, 1.0f));

        TextView title = new TextView(this);
        title.setText("EXAM BROWSER\nUJIAN ONLINE");
        title.setTextColor(Color.WHITE);
        title.setTextSize(25);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        page.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView sub = new TextView(this);
        sub.setText("Yayasan Bani Ihsan");
        sub.setTextColor(Color.rgb(255, 220, 60));
        sub.setTextSize(17);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(5), 0, dp(20));
        page.addView(sub);

        Button admin = makeButton("MASUK ADMIN", Color.rgb(255, 193, 7), Color.rgb(20, 45, 92));
        page.addView(admin, buttonParams());
        admin.setOnClickListener(v -> openPage(ADMIN_URL));

        Button guru = makeButton("MASUK GURU", Color.WHITE, Color.rgb(8, 64, 145));
        LinearLayout.LayoutParams gp = buttonParams(); gp.topMargin = dp(12);
        page.addView(guru, gp);
        guru.setOnClickListener(v -> openPage(GURU_URL));

        TextView foot = new TextView(this);
        foot.setText("Aplikasi resmi ujian online\nYayasan Bani Ihsan");
        foot.setTextColor(Color.WHITE);
        foot.setTextSize(12);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, dp(22), 0, 0);
        page.addView(foot);

        home = page;
        root.addView(page);
        setContentView(root);
    }

    private Button makeButton(String label, int bg, int fg) {
        Button b = new Button(this);
        b.setText(label); b.setTextSize(16); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(fg); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(bg));
        return b;
    }
    private LinearLayout.LayoutParams buttonParams() {
        return new LinearLayout.LayoutParams(-1, dp(54));
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private void openPage(String url) {
        if (webView == null) {
            webView = new WebView(this);
            webView.getSettings().setJavaScriptEnabled(true);
            webView.getSettings().setDomStorageEnabled(true);
            webView.getSettings().setDatabaseEnabled(true);
            webView.getSettings().setLoadWithOverviewMode(true);
            webView.getSettings().setUseWideViewPort(true);
            webView.addJavascriptInterface(new FileBridge(), "BaniIhsanFile");
            webView.setDownloadListener(new DownloadListener() {
                @Override public void onDownloadStart(String downloadUrl, String userAgent,
                        String contentDisposition, String mimeType, long contentLength) {
                    startHttpDownload(downloadUrl, userAgent, contentDisposition, mimeType);
                }
            });
            webView.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView view, String pageUrl) {
                    super.onPageFinished(view, pageUrl);
                    if (isTrustedPage(pageUrl)) installBlobDownloadSupport();
                }
                @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    Uri uri = request.getUrl();
                    String host = uri.getHost();
                    if ("admin-ujian-bani-ihsan.pages.dev".equals(host)
                            || "guru-ujian-bani-ihsan.pages.dev".equals(host)) return false;
                    if ("https".equals(uri.getScheme())) {
                        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { }
                    }
                    return true;
                }
            });
            webView.setWebChromeClient(new WebChromeClient());
        }
        if (webView.getParent() != null) ((FrameLayout)webView.getParent()).removeView(webView);
        root.removeAllViews();
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        inWeb = true;
        webView.loadUrl(url);
    }

    private boolean isTrustedPage(String pageUrl) {
        if (pageUrl == null) return false;
        Uri uri = Uri.parse(pageUrl);
        String host = uri.getHost();
        return "admin-ujian-bani-ihsan.pages.dev".equals(host)
                || "guru-ujian-bani-ihsan.pages.dev".equals(host);
    }

    // XLSX.writeFile() umumnya membuat tautan blob: yang tidak ditangani DownloadListener WebView.
    private void installBlobDownloadSupport() {
        String script =
            "(function(){"
            + "if(window.__baniIhsanBlobHook)return;window.__baniIhsanBlobHook=true;"
            + "document.addEventListener('click',function(e){"
            + "var a=e.target&&e.target.closest?e.target.closest('a[download]'):null;"
            + "if(!a)return;var href=a.href||'';if(href.indexOf('blob:')!==0)return;"
            + "e.preventDefault();e.stopPropagation();"
            + "var name=a.getAttribute('download')||'Nilai_Ujian_Bani_Ihsan.xlsx';"
            + "fetch(href).then(function(r){return r.blob();}).then(function(blob){"
            + "var reader=new FileReader();reader.onloadend=function(){"
            + "var data=String(reader.result||'');var comma=data.indexOf(',');"
            + "BaniIhsanFile.saveBlob(name,blob.type||'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',data.substring(comma+1));"
            + "};reader.readAsDataURL(blob);"
            + "}).catch(function(){alert('File Excel gagal disiapkan. Silakan coba kembali.');});"
            + "},true);})();";
        webView.evaluateJavascript(script, null);
    }

    private class FileBridge {
        @JavascriptInterface
        public void saveBlob(String fileName, String mimeType, String base64) {
            runOnUiThread(() -> {
                try {
                    String safeName = fileName == null ? "Nilai_Ujian_Bani_Ihsan.xlsx" : fileName;
                    safeName = safeName.substring(safeName.lastIndexOf('/') + 1);
                    safeName = safeName.replaceAll("[\\\\/:*?\"<>|]", "_");
                    if (safeName.trim().isEmpty()) safeName = "Nilai_Ujian_Bani_Ihsan.xlsx";
                    byte[] bytes = Base64.decode(base64 == null ? "" : base64, Base64.DEFAULT);
                    if (bytes.length == 0) {
                        Toast.makeText(MainActivity.this, "File Excel kosong.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    pendingBytes = bytes;
                    pendingName = safeName;
                    pendingMime = (mimeType == null || mimeType.trim().isEmpty())
                            ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" : mimeType;
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(pendingMime);
                    intent.putExtra(Intent.EXTRA_TITLE, pendingName);
                    startActivityForResult(intent, CREATE_FILE_REQUEST);
                } catch (Exception ex) {
                    Toast.makeText(MainActivity.this, "Tidak dapat menyiapkan file Excel.", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    private void startHttpDownload(String url, String userAgent, String disposition, String mimeType) {
        try {
            Uri uri = Uri.parse(url);
            if (!"https".equals(uri.getScheme()) && !"http".equals(uri.getScheme())) {
                Toast.makeText(this, "Tautan unduhan tidak didukung.", Toast.LENGTH_LONG).show();
                return;
            }
            String fileName = URLUtil.guessFileName(url, disposition, mimeType);
            DownloadManager.Request request = new DownloadManager.Request(uri);
            request.setTitle(fileName);
            request.setDescription("Mengunduh file dari Ujian Digital Bani Ihsan");
            request.setMimeType(mimeType);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) request.addRequestHeader("Cookie", cookie);
            if (userAgent != null) request.addRequestHeader("User-Agent", userAgent);
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
            DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            manager.enqueue(request);
            Toast.makeText(this, "Unduhan dimulai. Periksa folder Download.", Toast.LENGTH_LONG).show();
        } catch (Exception ex) {
            Toast.makeText(this, "Unduhan gagal dimulai. Coba gunakan browser.", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != CREATE_FILE_REQUEST) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            pendingBytes = null;
            Toast.makeText(this, "Penyimpanan file dibatalkan.", Toast.LENGTH_SHORT).show();
            return;
        }
        byte[] bytes = pendingBytes;
        pendingBytes = null;
        if (bytes == null) return;
        try {
            OutputStream output = getContentResolver().openOutputStream(data.getData());
            if (output == null) throw new IllegalStateException("Output stream unavailable");
            output.write(bytes);
            output.flush();
            output.close();
            Toast.makeText(this, "File Excel berhasil disimpan.", Toast.LENGTH_LONG).show();
        } catch (Exception ex) {
            Toast.makeText(this, "Gagal menyimpan. Silakan pilih folder Download.", Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onBackPressed() {
        if (inWeb && webView != null) {
            if (webView.canGoBack()) webView.goBack();
            else { inWeb = false; root.removeAllViews(); root.addView(home); }
        } else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
