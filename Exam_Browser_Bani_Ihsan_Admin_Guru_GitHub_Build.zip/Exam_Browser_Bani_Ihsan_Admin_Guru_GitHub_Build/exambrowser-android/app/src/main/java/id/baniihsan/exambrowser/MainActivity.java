package id.baniihsan.exambrowser;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private FrameLayout root;
    private View home;
    private boolean inWeb = false;
    private static final String ADMIN_URL = "https://admin-ujian-bani-ihsan.pages.dev/";
    private static final String GURU_URL = "https://guru-ujian-bani-ihsan.pages.dev/";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8, 53, 132));
        getWindow().setNavigationBarColor(Color.rgb(5, 30, 76));
        buildHome();
    }

    private void buildHome() {
        root = new FrameLayout(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(dp(22), dp(24), dp(22), dp(24));
        page.setBackgroundColor(Color.rgb(5, 67, 157));

        ImageView logo = new ImageView(this);
        int imageId = getResources().getIdentifier("exam_logo", "drawable", getPackageName());
        if (imageId != 0) logo.setImageResource(imageId);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        page.addView(logo, new LinearLayout.LayoutParams(-1, 0, 1.0f));

        TextView title = new TextView(this);
        title.setText("EXAM BROWSER\nUJIAN ONLINE");
        title.setTextColor(Color.WHITE);
        title.setTextSize(25);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        page.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView sub = new TextView(this);
        sub.setText("Yayasan Bani Ihsan");
        sub.setTextColor(Color.rgb(255, 220, 60));
        sub.setTextSize(17);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(5), 0, dp(20));
        page.addView(sub);

        Button admin = makeButton("MASUK ADMIN", Color.rgb(255, 193, 7), Color.rgb(20, 45, 92));
        page.addView(admin, buttonParams());
        admin.setOnClickListener(v -> openPage(ADMIN_URL));

        Button guru = makeButton("MASUK GURU", Color.WHITE, Color.rgb(8, 64, 145));
        LinearLayout.LayoutParams gp = buttonParams(); gp.topMargin = dp(12);
        page.addView(guru, gp);
        guru.setOnClickListener(v -> openPage(GURU_URL));

        TextView foot = new TextView(this);
        foot.setText("Aplikasi resmi ujian online\nYayasan Bani Ihsan");
        foot.setTextColor(Color.WHITE);
        foot.setTextSize(12);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, dp(22), 0, 0);
        page.addView(foot);

        home = page;
        root.addView(page);
        setContentView(root);
    }

    private Button makeButton(String label, int bg, int fg) {
        Button b = new Button(this);
        b.setText(label); b.setTextSize(16); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(fg); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(bg));
        return b;
    }
    private LinearLayout.LayoutParams buttonParams() {
        return new LinearLayout.LayoutParams(-1, dp(54));
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private void openPage(String url) {
        if (webView == null) {
            webView = new WebView(this);
            webView.getSettings().setJavaScriptEnabled(true);
            webView.getSettings().setDomStorageEnabled(true);
            webView.getSettings().setDatabaseEnabled(true);
            webView.getSettings().setLoadWithOverviewMode(true);
            webView.getSettings().setUseWideViewPort(true);
            webView.setWebViewClient(new WebViewClient());
            webView.setWebChromeClient(new WebChromeClient());
        }
        if (webView.getParent() != null) ((FrameLayout)webView.getParent()).removeView(webView);
        root.removeAllViews();
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        inWeb = true;
        webView.loadUrl(url);
    }

    @Override public void onBackPressed() {
        if (inWeb && webView != null) {
            if (webView.canGoBack()) webView.goBack();
            else { inWeb = false; root.removeAllViews(); root.addView(home); }
        } else super.onBackPressed();
    }
}
